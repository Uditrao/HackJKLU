"use client";

import { useState, useEffect } from "react";
import Link from "next/link";
import { motion, AnimatePresence } from "framer-motion";
import { useRouter } from "next/navigation";
import "./Game.css";

type UserData = {
    name: string;
    age: string;
    area: string;
};

// ── Inline SVG Illustration ────────────────────────────────────────────────
function GameIllustration() {
    return (
        <svg
            className="game-svg-illustration"
            viewBox="0 0 360 230"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
            aria-label="Three friends gathered around an unfinished Punjabi game board"
        >
            {/* ── GAME BOARD (unfinished) ── */}
            <rect x="100" y="130" width="160" height="100" rx="14" fill="#EDE9DE" stroke="#D4CFC2" strokeWidth="1.5" />
            {/* Grid lines on board — partly drawn */}
            <line x1="140" y1="130" x2="140" y2="230" stroke="#D4CFC2" strokeWidth="1" strokeDasharray="5 5" />
            <line x1="180" y1="130" x2="180" y2="230" stroke="#D4CFC2" strokeWidth="1" strokeDasharray="5 5" />
            <line x1="220" y1="130" x2="220" y2="230" stroke="#D4CFC2" strokeWidth="1" strokeDasharray="5 5" />
            <line x1="100" y1="165" x2="260" y2="165" stroke="#D4CFC2" strokeWidth="1" strokeDasharray="5 5" />
            <line x1="100" y1="200" x2="260" y2="200" stroke="#D4CFC2" strokeWidth="1" strokeDasharray="5 5" />
            {/* Paintbrush stroke — partially applied to board */}
            <path d="M100 148 Q130 140 155 152" stroke="#5C6BC0" strokeWidth="2.5" strokeLinecap="round" opacity="0.5" />

            {/* ── DICE ── */}
            <rect x="196" y="148" width="36" height="36" rx="7" fill="#E8834A" opacity="0.9" />
            <circle cx="206" cy="158" r="2.5" fill="white" />
            <circle cx="222" cy="158" r="2.5" fill="white" />
            <circle cx="214" cy="166" r="2.5" fill="white" />
            <circle cx="206" cy="174" r="2.5" fill="white" />
            <circle cx="222" cy="174" r="2.5" fill="white" />

            {/* ── FLOATING PUNJABI LETTERS ── */}
            {/* ਖੇਡ */}
            <text x="64" y="72" fontSize="20" fill="#E8834A" opacity="0.85" fontWeight="600">ਖੇਡ</text>
            {/* ਸ਼ਬਦ */}
            <text x="256" y="62" fontSize="17" fill="#5C6BC0" opacity="0.8" fontWeight="600">ਸ਼ਬਦ</text>
            {/* Small floating letter */}
            <text x="290" y="100" fontSize="13" fill="#E8834A" opacity="0.5">ਕ</text>
            <text x="50" y="110" fontSize="13" fill="#5C6BC0" opacity="0.45">ਮ</text>

            {/* ── PERSON 1 — left, leaning in with hands on knees ── */}
            {/* body */}
            <ellipse cx="82" cy="200" rx="22" ry="14" fill="#E8EAF6" />
            <rect x="64" y="165" width="36" height="42" rx="10" fill="#5C6BC0" />
            {/* head */}
            <circle cx="82" cy="148" r="18" fill="#F5DEB3" />
            {/* hair */}
            <path d="M64 140 Q82 125 100 140" fill="#5A4030" />
            {/* eyes */}
            <ellipse cx="76" cy="148" rx="2.5" ry="3" fill="#3E2A1A" />
            <ellipse cx="88" cy="148" rx="2.5" ry="3" fill="#3E2A1A" />
            {/* expression — curious lean */}
            <path d="M76 158 Q82 163 88 158" stroke="#3E2A1A" strokeWidth="1.5" strokeLinecap="round" fill="none" />
            {/* arms leaning on knees */}
            <path d="M64 175 Q50 190 58 205" stroke="#5C6BC0" strokeWidth="7" strokeLinecap="round" />
            <path d="M100 175 Q114 190 106 205" stroke="#5C6BC0" strokeWidth="7" strokeLinecap="round" />

            {/* ── PERSON 2 — center back, holding paintbrush ── */}
            {/* body */}
            <rect x="152" y="60" width="30" height="40" rx="10" fill="#2D3A8C" />
            {/* head */}
            <circle cx="167" cy="48" r="16" fill="#D2A679" />
            {/* hair */}
            <path d="M151 40 Q167 26 183 40" fill="#2C1A0E" />
            {/* eyes */}
            <ellipse cx="161" cy="48" rx="2" ry="2.5" fill="#1A0D00" />
            <ellipse cx="173" cy="48" rx="2" ry="2.5" fill="#1A0D00" />
            {/* smile */}
            <path d="M161 57 Q167 62 173 57" stroke="#1A0D00" strokeWidth="1.5" strokeLinecap="round" fill="none" />
            {/* arm holding paintbrush */}
            <path d="M182 78 Q210 95 190 120" stroke="#2D3A8C" strokeWidth="7" strokeLinecap="round" />
            {/* paintbrush */}
            <line x1="190" y1="120" x2="168" y2="148" stroke="#8B6F47" strokeWidth="3" strokeLinecap="round" />
            <ellipse cx="164" cy="152" rx="5" ry="3" fill="#5C6BC0" transform="rotate(-40 164 152)" />

            {/* ── PERSON 3 — right, cross-legged, patient look ── */}
            {/* cross-legged base */}
            <ellipse cx="284" cy="210" rx="26" ry="12" fill="#E8EAF6" />
            {/* body */}
            <rect x="266" y="168" width="36" height="44" rx="10" fill="#5C6BC0" />
            {/* head */}
            <circle cx="284" cy="152" r="17" fill="#F5DEB3" />
            {/* hair — long */}
            <path d="M267 144 Q284 128 301 144" fill="#2C1A0E" />
            <rect x="267" y="143" width="4" height="30" rx="2" fill="#2C1A0E" />
            <rect x="313" y="143" width="4" height="30" rx="2" fill="#2C1A0E" />
            {/* eyes */}
            <ellipse cx="278" cy="152" rx="2.5" ry="3" fill="#3E2A1A" />
            <ellipse cx="290" cy="152" rx="2.5" ry="3" fill="#3E2A1A" />
            {/* patient expression */}
            <path d="M277 162 Q284 165 291 162" stroke="#3E2A1A" strokeWidth="1.5" strokeLinecap="round" fill="none" />
            {/* arms resting */}
            <path d="M266 185 Q252 198 264 212" stroke="#5C6BC0" strokeWidth="7" strokeLinecap="round" />
            <path d="M302 185 Q316 198 304 212" stroke="#5C6BC0" strokeWidth="7" strokeLinecap="round" />

            {/* ── SMALL ACCENT DOTS ── */}
            <circle cx="168" cy="22" r="4" fill="#E8834A" opacity="0.4" />
            <circle cx="300" cy="38" r="3" fill="#5C6BC0" opacity="0.3" />
            <circle cx="44" cy="155" r="2.5" fill="#E8834A" opacity="0.3" />
        </svg>
    );
}

// ── Page Component ─────────────────────────────────────────────────────────
export default function GamePage() {
    const router = useRouter();
    const [user, setUser] = useState<UserData | null>(null);
    const [notified, setNotified] = useState(false);

    useEffect(() => {
        const fetchUser = async () => {
            try {
                const res = await fetch("/web/api/user-details");
                const data = await res.json();
                setUser(data);
            } catch {
                // silent
            }
        };
        fetchUser();
    }, []);

    const initials = user?.name?.slice(0, 2).toUpperCase() || "B";

    const handleNotify = () => {
        if (notified) return;
        setNotified(true);
    };

    return (
        <div className="game-container">
            {/* ── SIDEBAR ── */}
            <aside className="sidebar">
                <div className="logo">BOLI</div>
                <div className="logo-sub">Language Learning</div>

                <nav className="nav">
                    <Link href="/web/dashboard" className="nav-item">
                        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                            <rect x="3" y="3" width="7" height="7" rx="1" /><rect x="14" y="3" width="7" height="7" rx="1" />
                            <rect x="3" y="14" width="7" height="7" rx="1" /><rect x="14" y="14" width="7" height="7" rx="1" />
                        </svg>
                        Dashboard
                    </Link>

                    <Link href="/web/analyse" className="nav-item">
                        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                            <line x1="18" y1="20" x2="18" y2="10" /><line x1="12" y1="20" x2="12" y2="4" /><line x1="6" y1="20" x2="6" y2="14" />
                        </svg>
                        Analyse
                    </Link>

                    <Link href="/web/chat" className="nav-item">
                        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                            <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z" />
                        </svg>
                        Chat
                    </Link>

                    <Link href="/web/game" className="nav-item active">
                        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                            <line x1="6" y1="12" x2="10" y2="12" /><line x1="8" y1="10" x2="8" y2="14" />
                            <circle cx="15" cy="11" r="1" fill="currentColor" /><circle cx="17" cy="13" r="1" fill="currentColor" />
                            <rect x="2" y="6" width="20" height="12" rx="4" />
                        </svg>
                        Game
                    </Link>

                    <Link href="/web/shadow" className="nav-item">
                        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                            <path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z" />
                        </svg>
                        Shadow Mode
                    </Link>

                    <div className="nav-divider" />
                </nav>

                <div className="profile-section">
                    <div className="avatar">{initials}</div>
                    <div>
                        <div className="profile-name">{user?.name || "Learner"}</div>
                        <div className="profile-label">Profile</div>
                    </div>
                </div>
            </aside>

            {/* ── MAIN ── */}
            <main className="game-main">
                <motion.div
                    className="game-center"
                    initial={{ opacity: 0, y: 24 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.6, ease: [0.4, 0, 0.2, 1] }}
                >
                    {/* Illustration */}
                    <div className="game-illustration-wrap">
                        <GameIllustration />
                        <div className="game-illustration-shadow" />
                    </div>

                    {/* Headline */}
                    <h1 className="game-headline">
                        Games are coming —<br />
                        learn language by living it.
                    </h1>
                    <div className="game-headline-punjabi">ਭਾਸ਼ਾ ਜ਼ਿੰਦਗੀ ਜਿਉਂਦੇ ਹੋਏ ਸਿੱਖੋ।</div>

                    {/* Description */}
                    <p className="game-description">
                        We&apos;re building interactive games that teach Punjabi through stories, markets,
                        and real-life moments. Something worth waiting for.
                    </p>

                    {/* Icon trio */}
                    <div className="game-icon-row">
                        <div className="game-icon-item">
                            <div className="game-icon-circle">🛒</div>
                            <span className="game-icon-label">Market</span>
                        </div>
                        <div className="game-icon-item">
                            <div className="game-icon-circle">🚂</div>
                            <span className="game-icon-label">Travel</span>
                        </div>
                        <div className="game-icon-item">
                            <div className="game-icon-circle">🍽️</div>
                            <span className="game-icon-label">Family</span>
                        </div>
                    </div>

                    {/* Action buttons */}
                    <div className="game-btn-stack">
                        <motion.button
                            className={`game-btn-primary ${notified ? "confirmed" : ""}`}
                            onClick={handleNotify}
                            whileTap={notified ? {} : { scale: 0.96 }}
                            aria-label="Notify me when games launch"
                        >
                            <AnimatePresence mode="wait">
                                {notified ? (
                                    <motion.span
                                        key="confirmed"
                                        initial={{ opacity: 0, y: 6 }}
                                        animate={{ opacity: 1, y: 0 }}
                                        exit={{ opacity: 0 }}
                                        transition={{ duration: 0.2 }}
                                    >
                                        {"You're on the list ✓"}
                                    </motion.span>
                                ) : (
                                    <motion.span
                                        key="default"
                                        initial={{ opacity: 0, y: -6 }}
                                        animate={{ opacity: 1, y: 0 }}
                                        exit={{ opacity: 0 }}
                                        transition={{ duration: 0.2 }}
                                    >
                                        Notify Me When Games Launch
                                    </motion.span>
                                )}
                            </AnimatePresence>
                        </motion.button>

                        <button
                            className="game-btn-secondary"
                            onClick={() => router.push("/web/shadow")}
                        >
                            Explore Flashcards Instead
                        </button>
                    </div>

                    {/* Ambient quote */}
                    <div className="game-ambient">
                        <div className="game-ambient-punjabi">ਖੇਡ ਵਿੱਚ ਸਿੱਖਣਾ, ਸਭ ਤੋਂ ਡੂੰਘਾ ਸਿੱਖਣਾ ਹੈ।</div>
                        <div className="game-ambient-english">Learning through play is the deepest learning of all.</div>
                    </div>
                </motion.div>
            </main>
        </div>
    );
}
