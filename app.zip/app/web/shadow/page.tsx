"use client";

import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import { AnimatePresence, motion } from "framer-motion";
import "./Shadow.css";

// ── Types ──────────────────────────────────────────────────────────────────
type PageState = "entry" | "flashcards" | "quiz";
type CardState = "deck-overview" | "front" | "flipped" | "session-done";
type QuizState = "overview" | "question" | "between" | "silence" | "summary";
type QuestionType = "listening-mcq" | "speaking";

interface Flashcard {
    id: number;
    script: string;
    roman: string;
    meaning: string;
    cultural: string;
}

interface QuizQuestion {
    type: QuestionType;
    sentence?: string;
    hintChips?: string[];
    expectedAnswer?: string;
    options?: string[];
    correctIndex?: number;
    audio?: string;
}

// ── Data ──────────────────────────────────────────────────────────────────
const FLASHCARDS: Flashcard[] = [
    { id: 1, script: "ਸਤ ਸ੍ਰੀ ਅਕਾਲ", roman: "Sat Sri Akal", meaning: "Hello / God is Truth", cultural: "Said when greeting anyone, regardless of time of day. Deeply respectful in Sikh tradition." },
    { id: 2, script: "ਧੰਨਵਾਦ", roman: "Dhanyavaad", meaning: "Thank you", cultural: "Used formally. In casual settings, Punjabi speakers often smile and nod instead — the word carries weight." },
    { id: 3, script: "ਤੁਸੀਂ ਕਿਵੇਂ ਹੋ?", roman: "Tusīṃ kivēṃ ho?", meaning: "How are you?", cultural: "Asked with genuine interest. Answering briefly is fine; you aren't expected to share everything." },
    { id: 4, script: "ਘਰ", roman: "Ghar", meaning: "Home / House", cultural: "More than a building — ghar implies warmth, belonging, and family. A deeply emotional word." },
    { id: 5, script: "ਪਾਣੀ", roman: "Pāṇī", meaning: "Water", cultural: "Offering water to a guest before anything else is a cardinal rule of Punjabi hospitality." },
    { id: 6, script: "ਖਾਣਾ ਖਾਓ", roman: "Khāṇā khāo", meaning: "Please eat / Have some food", cultural: "Not a question — it's a warm command. Refusing food multiple times is expected before accepting." },
];

const ENCOURAGEMENTS = [
    { punjabi: "ਚੰਗਾ।", english: "Good." },
    { punjabi: "ਅੱਗੇ ਵਧੋ।", english: "Keep going." },
    { punjabi: "ਸ਼ਾਬਾਸ਼।", english: "Well done." },
    { punjabi: "ਕੋਈ ਗੱਲ ਨਹੀਂ।", english: "No worries." },
    { punjabi: "ਤੂੰ ਕਰ ਸਕਦਾ ਹੈਂ।", english: "You can do this." },
];

const BETWEEN_PHRASES = [
    "You're doing well.",
    "Almost there.",
    "Take your time.",
    "Every word counts.",
    "You're here. That's what matters.",
];

const QUIZ_QUESTIONS: QuizQuestion[] = [
    {
        type: "listening-mcq",
        options: ["Hello / God is Truth", "Thank you", "How are you?", "Please eat"],
        correctIndex: 0,
        audio: "ਸਤ ਸ੍ਰੀ ਅਕਾਲ",
    },
    {
        type: "speaking",
        sentence: "Tell me your name in Punjabi.",
        hintChips: ["Mera naav", "Tussi", "Ki hai?"],
        expectedAnswer: "Mera naav … hai. (My name is …)",
    },
    {
        type: "listening-mcq",
        options: ["Water", "Home", "Food", "Hello"],
        correctIndex: 0,
        audio: "ਪਾਣੀ",
    },
    {
        type: "speaking",
        sentence: "How would you greet an elder in the morning?",
        hintChips: ["Sat Sri Akal", "Pairi payna"],
        expectedAnswer: "Sat Sri Akal — and touching their feet (Pairi payna) shows deep respect.",
    },
    {
        type: "listening-mcq",
        options: ["Thank you", "Home", "Water", "Keep going"],
        correctIndex: 0,
        audio: "ਧੰਨਵਾਦ",
    },
    {
        type: "speaking",
        sentence: "Say 'Please have some food' (Khana khao) to a guest.",
        hintChips: ["Khana khao", "Ji zaroor"],
        expectedAnswer: "Khāṇā khāo — said warmly, often repeated until accepted.",
    },
];

// ── Component ──────────────────────────────────────────────────────────────
export default function ShadowModePage() {
    const router = useRouter();

    // ── Page State
    const [pageState, setPageState] = useState<PageState>("entry");
    const [activeTab, setActiveTab] = useState<"flashcards" | "quiz">("flashcards");


    // ── Flashcard State
    const [cardState, setCardState] = useState<CardState>("deck-overview");
    const [cardIndex, setCardIndex] = useState(0);
    const [isFlipped, setIsFlipped] = useState(false);
    const [speakerPlaying, setSpeakerPlaying] = useState(false);

    const handleBeginFlashcards = () => {
        setCardState("front");
        setCardIndex(0);
        setIsFlipped(false);
    };

    const handleFlipCard = () => {
        if (!isFlipped) setIsFlipped(true);
    };

    const handleSeeAgain = () => {
        setIsFlipped(false);
        // send to back by cycling to next, then card comes around again
        setCardIndex((prev) => (prev + 1) % FLASHCARDS.length);
    };

    const handleNextCard = () => {
        setIsFlipped(false);
        if (cardIndex + 1 >= FLASHCARDS.length) {
            setCardState("session-done");
        } else {
            setCardIndex((prev) => prev + 1);
        }
    };

    const handleSpeaker = (e: React.MouseEvent) => {
        e.stopPropagation();
        setSpeakerPlaying(true);
        setTimeout(() => setSpeakerPlaying(false), 700);
    };

    // ── Quiz State
    const [quizState, setQuizState] = useState<QuizState>("overview");
    const [questionIndex, setQuestionIndex] = useState(0);
    const [selectedOption, setSelectedOption] = useState<number | null>(null);
    const [isRecording, setIsRecording] = useState(false);
    const [transcription, setTranscription] = useState("");
    const [showAnswer, setShowAnswer] = useState(false);
    const [audioPlaying, setAudioPlaying] = useState(false);
    const [betweenPhrase, setBetweenPhrase] = useState(ENCOURAGEMENTS[0]);
    const [betweenEncourage, setBetweenEncourage] = useState("");

    const beginQuiz = () => {
        setQuestionIndex(0);
        setSelectedOption(null);
        setTranscription("");
        setShowAnswer(false);
        setIsRecording(false);
        setQuizState("question");
    };

    const handleSelectOption = (i: number) => {
        if (selectedOption !== null) return;
        setSelectedOption(i);
    };

    const handlePlayAudio = () => {
        setAudioPlaying(true);
        setTimeout(() => setAudioPlaying(false), 1800);
    };

    const handleMicToggle = () => {
        if (!isRecording) {
            setIsRecording(true);
        } else {
            setIsRecording(false);
            setTranscription("Sat Sri Akal — Tussi kiddan ho?");
        }
    };

    const goNextQuestion = () => {
        const randE = ENCOURAGEMENTS[Math.floor(Math.random() * ENCOURAGEMENTS.length)];
        const randB = BETWEEN_PHRASES[Math.floor(Math.random() * BETWEEN_PHRASES.length)];
        setBetweenPhrase(randE);
        setBetweenEncourage(randB);
        setQuizState("between");
        setSelectedOption(null);
        setTranscription("");
        setShowAnswer(false);
        setIsRecording(false);
        setAudioPlaying(false);

        setTimeout(() => {
            if (questionIndex + 1 >= QUIZ_QUESTIONS.length) {
                setQuizState("silence");
                setTimeout(() => setQuizState("summary"), 1000);
            } else {
                setQuestionIndex((prev) => prev + 1);
                setQuizState("question");
            }
        }, 1200);
    };

    const currentQ = QUIZ_QUESTIONS[questionIndex];
    const progress = (questionIndex / QUIZ_QUESTIONS.length) * 100;
    const flashProgress = ((cardIndex + 1) / FLASHCARDS.length) * 100;

    const enterShadowMode = () => {
        setPageState("flashcards");
        setActiveTab("flashcards");
        setCardState("deck-overview");
    };

    const switchToQuizFromDone = () => {
        setActiveTab("quiz");
        setQuizState("overview");
    };

    const leaveQuiz = () => {
        router.push("/web/dashboard");
    };

    const resetFlashcards = () => {
        setCardIndex(0);
        setIsFlipped(false);
        setCardState("deck-overview");
    };

    return (
        <div className="sm-root">

            {/* ── ENTRY SCREEN ── */}
            <AnimatePresence mode="wait">
                {pageState === "entry" && (
                    <motion.div
                        key="entry"
                        className="sm-entry"
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        exit={{ opacity: 0, transition: { duration: 0.6 } }}
                        transition={{ duration: 0.8 }}
                    >
                        <div className="sm-entry-wordmark">BOLI</div>
                        <div className="sm-entry-tagline">
                            Take a breath. This is your space.
                            <span className="sm-entry-punjabi">ਇੱਥੇ ਕੋਈ ਜਲਦੀ ਨਹੀਂ।</span>
                            <span style={{ display: "block", fontSize: "12px", color: "var(--sm-text-muted)", marginTop: "4px" }}>
                                There is no hurry here.
                            </span>
                        </div>
                        <button className="sm-enter-btn" onClick={enterShadowMode}>
                            Enter Shadow Mode
                        </button>
                        <button
                            className="sm-entry-exit"
                            onClick={() => router.push("/web/dashboard")}
                        >
                            ← Back to Dashboard
                        </button>
                    </motion.div>
                )}
            </AnimatePresence>

            {/* ── MAIN INTERFACE ── */}
            <AnimatePresence>
                {pageState !== "entry" && (
                    <motion.div
                        key="interface"
                        className="sm-interface"
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        transition={{ duration: 0.8 }}
                    >
                        {/* Leave button — always visible, top-right */}
                        <button
                            className="sm-leave-btn"
                            onClick={() => router.push("/web/dashboard")}
                            aria-label="Leave Shadow Mode"
                        >
                            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                                <polyline points="15 18 9 12 15 6" />
                            </svg>
                            Leave
                        </button>

                        {/* Segmented Control */}
                        <div className="sm-tabs">
                            <button
                                className={`sm-tab ${activeTab === "flashcards" ? "active" : ""}`}
                                onClick={() => { setActiveTab("flashcards"); setCardState("deck-overview"); }}
                            >
                                Flashcards
                            </button>
                            <button
                                className={`sm-tab ${activeTab === "quiz" ? "active" : ""}`}
                                onClick={() => { setActiveTab("quiz"); setQuizState("overview"); }}
                            >
                                Quiz
                            </button>
                        </div>
                        <div className="sm-context-line">Punjabi · Adult Stage · Daily Basics</div>

                        {/* ── CONTENT ── */}
                        <div className="sm-content">

                            {/* ════════════════════════════════
                  FLASHCARDS TAB
              ════════════════════════════════ */}
                            <AnimatePresence mode="wait">
                                {activeTab === "flashcards" && (
                                    <motion.div
                                        key={`fc-${cardState}-${cardIndex}`}
                                        initial={{ opacity: 0, y: 16 }}
                                        animate={{ opacity: 1, y: 0 }}
                                        exit={{ opacity: 0 }}
                                        transition={{ duration: 0.35 }}
                                        style={{ display: "flex", flexDirection: "column", alignItems: "center", width: "100%" }}
                                    >
                                        {/* ── Deck Overview ── */}
                                        {cardState === "deck-overview" && (
                                            <>
                                                <div className="sm-deck-name">Daily Greetings · {FLASHCARDS.length} cards</div>
                                                <div className="sm-card-stack">
                                                    <div className="sm-stack-ghost sm-stack-ghost-1" />
                                                    <div className="sm-stack-ghost sm-stack-ghost-2" />
                                                    {/* Top card face preview */}
                                                    <div style={{
                                                        position: "absolute", inset: 0,
                                                        background: "var(--sm-surface)",
                                                        borderRadius: "20px",
                                                        display: "flex", flexDirection: "column",
                                                        alignItems: "center", justifyContent: "center",
                                                        boxShadow: "0 12px 48px rgba(0,0,0,0.5)",
                                                        gap: "8px",
                                                    }}>
                                                        <span style={{ fontSize: "38px", color: "var(--sm-text-primary)" }}>ਸਤ ਸ੍ਰੀ ਅਕਾਲ</span>
                                                        <span style={{ fontSize: "13px", color: "var(--sm-text-muted)" }}>Sat Sri Akal</span>
                                                    </div>
                                                </div>
                                                <button className="sm-begin-btn" onClick={handleBeginFlashcards}>Begin</button>
                                            </>
                                        )}

                                        {/* ── Single Card ── */}
                                        {(cardState === "front" || cardState === "flipped") && (
                                            <>
                                                <div className="sm-flip-scene" onClick={handleFlipCard}>
                                                    <div className={`sm-flip-card ${isFlipped ? "flipped" : ""}`}>
                                                        {/* Front */}
                                                        <div className="sm-card-face sm-card-front">
                                                            <div className="sm-card-word">{FLASHCARDS[cardIndex].script}</div>
                                                            <div className="sm-card-roman">{FLASHCARDS[cardIndex].roman}</div>
                                                            <div className="sm-card-footer">
                                                                <button
                                                                    className={`sm-speaker ${speakerPlaying ? "playing" : ""}`}
                                                                    onClick={handleSpeaker}
                                                                    aria-label="Play audio"
                                                                >
                                                                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
                                                                        <polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5" />
                                                                        <path d="M15.54 8.46a5 5 0 0 1 0 7.07" />
                                                                        <path d="M19.07 4.93a10 10 0 0 1 0 14.14" />
                                                                    </svg>
                                                                </button>
                                                                <span className="sm-card-tap-hint">Tap to reveal</span>
                                                            </div>
                                                        </div>

                                                        {/* Back */}
                                                        <div className="sm-card-face sm-card-back">
                                                            <div className="sm-back-meaning">{FLASHCARDS[cardIndex].meaning}</div>
                                                            <div className="sm-back-script">{FLASHCARDS[cardIndex].script}</div>
                                                            <div className="sm-back-cultural">{FLASHCARDS[cardIndex].cultural}</div>
                                                            <div className="sm-card-footer">
                                                                <button
                                                                    className={`sm-speaker ${speakerPlaying ? "playing" : ""}`}
                                                                    onClick={handleSpeaker}
                                                                    aria-label="Play audio"
                                                                >
                                                                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
                                                                        <polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5" />
                                                                        <path d="M15.54 8.46a5 5 0 0 1 0 7.07" />
                                                                        <path d="M19.07 4.93a10 10 0 0 1 0 14.14" />
                                                                    </svg>
                                                                </button>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>

                                                {/* Card navigation — only after flip */}
                                                <AnimatePresence>
                                                    {isFlipped && (
                                                        <motion.div
                                                            className="sm-card-nav"
                                                            initial={{ opacity: 0, y: 10 }}
                                                            animate={{ opacity: 1, y: 0 }}
                                                            transition={{ duration: 0.3 }}
                                                        >
                                                            <button className="sm-see-again" onClick={handleSeeAgain}>← See again</button>
                                                            <button className="sm-next-btn" onClick={handleNextCard}>Next →</button>
                                                        </motion.div>
                                                    )}
                                                </AnimatePresence>

                                                {/* Progress thread */}
                                                <div className="sm-progress-area">
                                                    <div className="sm-progress-track">
                                                        <div className="sm-progress-fill" style={{ width: `${flashProgress}%` }} />
                                                    </div>
                                                    <div className="sm-progress-label">{cardIndex + 1} of {FLASHCARDS.length}</div>
                                                </div>
                                            </>
                                        )}

                                        {/* ── Session Done ── */}
                                        {cardState === "session-done" && (
                                            <>
                                                <div className="sm-done-message">
                                                    <span className="sm-done-punjabi">ਸ਼ਾਬਾਸ਼।</span>
                                                    <span className="sm-done-sub">Well done. Rest, or go again.</span>
                                                </div>
                                                <div className="sm-done-cards">
                                                    {FLASHCARDS.slice(0, 3).map((_, i) => (
                                                        <div key={i} className="sm-done-card-mini" />
                                                    ))}
                                                </div>
                                                <div className="sm-ghost-btns">
                                                    <button className="sm-ghost-btn" onClick={resetFlashcards}>Review again</button>
                                                    <button className="sm-ghost-btn" onClick={switchToQuizFromDone}>Switch to Quiz</button>
                                                </div>
                                            </>
                                        )}
                                    </motion.div>
                                )}
                            </AnimatePresence>

                            {/* ════════════════════════════════
                  QUIZ TAB
              ════════════════════════════════ */}
                            <AnimatePresence mode="wait">
                                {activeTab === "quiz" && (
                                    <motion.div
                                        key={`quiz-${quizState}-${questionIndex}`}
                                        initial={{ opacity: 0, y: 16 }}
                                        animate={{ opacity: 1, y: 0 }}
                                        exit={{ opacity: 0 }}
                                        transition={{ duration: 0.35 }}
                                        style={{ display: "flex", flexDirection: "column", alignItems: "center", width: "100%" }}
                                    >

                                        {/* ── Quiz Overview ── */}
                                        {quizState === "overview" && (
                                            <div className="sm-quiz-overview-card">
                                                <div className="sm-overview-lang">
                                                    <span className="sm-overview-langname">Punjabi</span>
                                                    <span className="sm-overview-script">ਪੰਜਾਬੀ</span>
                                                </div>
                                                <div className="sm-overview-row">
                                                    <span className="sm-overview-key">Level</span>
                                                    <span className="sm-pill indigo">Level 7 · Learner</span>
                                                </div>
                                                <div className="sm-overview-row">
                                                    <span className="sm-overview-key">Difficulty</span>
                                                    <span className="sm-pill green">Beginner</span>
                                                </div>
                                                <div className="sm-overview-row">
                                                    <span className="sm-overview-key">Theme</span>
                                                    <span style={{ fontSize: "13px", color: "var(--sm-text-secondary)" }}>Daily Basics · Greetings and Home</span>
                                                </div>
                                                <div className="sm-overview-row">
                                                    <span className="sm-overview-key">Focus</span>
                                                    <div className="sm-focus-pills">
                                                        {["Vocabulary Recall", "Listening", "Speaking"].map(f => (
                                                            <span key={f} className="sm-pill warm">{f}</span>
                                                        ))}
                                                    </div>
                                                </div>
                                                <p className="sm-no-judge">
                                                    {QUIZ_QUESTIONS.length} questions · No time limit ·{" "}
                                                    <strong>No wrong answers judged.</strong>
                                                </p>
                                                <button className="sm-begin-quiz-btn" onClick={beginQuiz}>
                                                    Begin Quiz
                                                </button>
                                            </div>
                                        )}

                                        {/* ── Between Questions ── */}
                                        {quizState === "between" && (
                                            <div className="sm-between">
                                                <div className="sm-between-punjabi">{betweenPhrase.punjabi}</div>
                                                <div className="sm-between-english">{betweenPhrase.english}</div>
                                                <div style={{ marginTop: "12px", fontSize: "11px", color: "var(--sm-text-muted)", fontStyle: "italic" }}>
                                                    {betweenEncourage}
                                                </div>
                                            </div>
                                        )}

                                        {/* ── 1s Silence before summary ── */}
                                        {quizState === "silence" && (
                                            <div style={{ flex: 1 }} />
                                        )}

                                        {/* ── Active Question ── */}
                                        {quizState === "question" && (
                                            <>
                                                {/* Progress row */}
                                                <div className="sm-q-progress-row" style={{ width: "100%", maxWidth: "520px" }}>
                                                    <span className="sm-q-count">Question {questionIndex + 1} of {QUIZ_QUESTIONS.length}</span>
                                                    <span className="sm-q-encourage" style={{ fontSize: "11px" }}>
                                                        {BETWEEN_PHRASES[questionIndex % BETWEEN_PHRASES.length]}
                                                    </span>
                                                </div>
                                                <div className="sm-q-progress-track" style={{ width: "100%", maxWidth: "520px" }}>
                                                    <div className="sm-q-progress-fill" style={{ width: `${progress}%` }} />
                                                </div>

                                                {/* Question card */}
                                                <div className="sm-q-card">

                                                    {/* ── Listening MCQ ── */}
                                                    {currentQ.type === "listening-mcq" && (
                                                        <>
                                                            <p className="sm-listen-hint">Listen carefully.</p>
                                                            <button
                                                                className={`sm-audio-circle ${audioPlaying ? "playing" : ""}`}
                                                                onClick={handlePlayAudio}
                                                                aria-label="Play audio"
                                                            >
                                                                {audioPlaying ? (
                                                                    <svg width="22" height="22" viewBox="0 0 24 24" fill="white" stroke="none">
                                                                        <rect x="5" y="4" width="4" height="16" rx="1" />
                                                                        <rect x="15" y="4" width="4" height="16" rx="1" />
                                                                    </svg>
                                                                ) : (
                                                                    <svg width="22" height="22" viewBox="0 0 24 24" fill="var(--sm-accent)" stroke="none">
                                                                        <polygon points="5 3 19 12 5 21 5 3" />
                                                                    </svg>
                                                                )}
                                                            </button>
                                                            <p className="sm-listen-sub">Tap to hear the Punjabi word.</p>
                                                            <div className="sm-q-divider" />
                                                            <div className="sm-options">
                                                                {currentQ.options?.map((opt, i) => (
                                                                    <button
                                                                        key={i}
                                                                        className={`sm-option ${selectedOption === i ? "selected" : ""} ${selectedOption !== null && selectedOption !== i ? "dimmed" : ""}`}
                                                                        onClick={() => handleSelectOption(i)}
                                                                    >
                                                                        {opt}
                                                                    </button>
                                                                ))}
                                                            </div>
                                                            {selectedOption !== null && (
                                                                <motion.button
                                                                    className="sm-q-next-btn"
                                                                    initial={{ opacity: 0, y: 8 }}
                                                                    animate={{ opacity: 1, y: 0 }}
                                                                    onClick={goNextQuestion}
                                                                >
                                                                    Next Question →
                                                                </motion.button>
                                                            )}
                                                        </>
                                                    )}

                                                    {/* ── Speaking ── */}
                                                    {currentQ.type === "speaking" && (
                                                        <>
                                                            <p className="sm-speak-sentence">{currentQ.sentence}</p>
                                                            <div className="sm-hint-chips">
                                                                {currentQ.hintChips?.map(c => (
                                                                    <span key={c} className="sm-hint-chip">{c}</span>
                                                                ))}
                                                            </div>
                                                            <button
                                                                className={`sm-mic-circle ${isRecording ? "recording" : ""}`}
                                                                onClick={handleMicToggle}
                                                                aria-label={isRecording ? "Stop recording" : "Start recording"}
                                                            >
                                                                {isRecording ? (
                                                                    <div className="sm-waveform">
                                                                        {[1, 2, 3, 4, 5].map(i => <div key={i} className="sm-wave-bar" />)}
                                                                    </div>
                                                                ) : (
                                                                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="var(--sm-text-muted)" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                                                                        <path d="M12 1a3 3 0 0 0-3 3v8a3 3 0 0 0 6 0V4a3 3 0 0 0-3-3z" />
                                                                        <path d="M19 10v2a7 7 0 0 1-14 0v-2" />
                                                                        <line x1="12" y1="19" x2="12" y2="23" />
                                                                        <line x1="8" y1="23" x2="16" y2="23" />
                                                                    </svg>
                                                                )}
                                                            </button>
                                                            {transcription && (
                                                                <p className="sm-transcription">"{transcription}"</p>
                                                            )}
                                                            {!showAnswer && transcription && (
                                                                <button className="sm-show-answer-link" onClick={() => setShowAnswer(true)}>
                                                                    Show me the expected answer
                                                                </button>
                                                            )}
                                                            {showAnswer && (
                                                                <motion.p
                                                                    className="sm-revealed-answer"
                                                                    initial={{ opacity: 0 }}
                                                                    animate={{ opacity: 1 }}
                                                                >
                                                                    {currentQ.expectedAnswer}
                                                                </motion.p>
                                                            )}
                                                            {(transcription || showAnswer) && (
                                                                <motion.button
                                                                    className="sm-q-next-btn"
                                                                    initial={{ opacity: 0, y: 8 }}
                                                                    animate={{ opacity: 1, y: 0 }}
                                                                    onClick={goNextQuestion}
                                                                >
                                                                    Next Question →
                                                                </motion.button>
                                                            )}
                                                        </>
                                                    )}
                                                </div>
                                            </>
                                        )}

                                        {/* ── Summary ── */}
                                        {quizState === "summary" && (
                                            <div className="sm-summary">
                                                <div className="sm-summary-complete-punjabi">ਮੁਕੰਮਲ।</div>
                                                <div className="sm-summary-complete-sub">You finished your practice session.</div>

                                                <div className="sm-summary-card">
                                                    <div className="sm-summary-section">
                                                        <div className="sm-summary-label">Your Strengths</div>
                                                        <div className="sm-summary-pills">
                                                            {["Listening comprehension", "Response consistency", "Vocabulary recognition"].map(s => (
                                                                <span key={s} className="sm-pill green">{s}</span>
                                                            ))}
                                                        </div>
                                                    </div>

                                                    <div className="sm-summary-section">
                                                        <div className="sm-summary-label">Worth Exploring</div>
                                                        <div className="sm-summary-pills">
                                                            {["Speaking fluency", "Script recognition"].map(s => (
                                                                <span key={s} className="sm-pill warm">{s}</span>
                                                            ))}
                                                        </div>
                                                    </div>

                                                    <div className="sm-summary-section">
                                                        <div className="sm-summary-label">Completion</div>
                                                        <div className="sm-summary-count">
                                                            {QUIZ_QUESTIONS.length} of {QUIZ_QUESTIONS.length} questions answered.
                                                        </div>
                                                    </div>
                                                </div>

                                                <div className="sm-summary-actions">
                                                    <button className="sm-ghost-btn" onClick={beginQuiz}>Try Again</button>
                                                    <button className="sm-ghost-btn" onClick={() => { setActiveTab("flashcards"); setCardState("deck-overview"); }}>
                                                        Review Flashcards
                                                    </button>
                                                    <button className="sm-ghost-btn" onClick={leaveQuiz}>Leave Shadow Mode</button>
                                                </div>
                                            </div>
                                        )}

                                    </motion.div>
                                )}
                            </AnimatePresence>

                        </div>
                    </motion.div>
                )}
            </AnimatePresence>
        </div>
    );
}
