"use client";

import { useState, useEffect } from "react";
import Link from "next/link";
import { motion } from "framer-motion";
import "./Analyse.css";

type UserData = {
    name: string;
    age: string;
    area: string;
    id: string;
    createdAt: string;
    updatedAt: string;
};

export default function AnalysePage() {
    const [user, setUser] = useState<UserData | null>(null);
    const [isLoading, setIsLoading] = useState(true);

    useEffect(() => {
        const fetchUser = async () => {
            try {
                const res = await fetch("/web/api/user-details");
                const data = await res.json();
                setUser(data);
            } catch (error) {
                console.error("Failed to fetch user:", error);
            } finally {
                setIsLoading(false);
            }
        };
        fetchUser();
    }, []);

    if (isLoading) {
        return (
            <div className="min-h-screen bg-[#FAF9F3] flex items-center justify-center">
                <div className="w-12 h-12 border-4 border-[#2D3A8C] border-t-transparent rounded-full animate-spin" />
            </div>
        );
    }

    return (
        <div className="analyse-container">
            {/* SIDEBAR */}
            <aside className="sidebar">
                <div className="logo">BOLI</div>
                <div className="logo-sub">Language Learning</div>
                <nav className="nav">
                    <Link href="/web/dashboard" className="nav-item">
                        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect x="3" y="3" width="7" height="7" rx="1" /><rect x="14" y="3" width="7" height="7" rx="1" /><rect x="3" y="14" width="7" height="7" rx="1" /><rect x="14" y="14" width="7" height="7" rx="1" /></svg>
                        Dashboard
                    </Link>
                    <Link href="/web/analyse" className="nav-item active">
                        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="18" y1="20" x2="18" y2="10" /><line x1="12" y1="20" x2="12" y2="4" /><line x1="6" y1="20" x2="6" y2="14" /></svg>
                        Analyse
                    </Link>
                    <Link href="/web/chat" className="nav-item">
                        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z" /></svg>
                        Chat
                    </Link>
                    <Link href="/web/game" className="nav-item">
                        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="6" y1="12" x2="10" y2="12" /><line x1="8" y1="10" x2="8" y2="14" /><circle cx="15" cy="11" r="1" fill="currentColor" /><circle cx="17" cy="13" r="1" fill="currentColor" /><rect x="2" y="6" width="20" height="12" rx="4" /></svg>
                        Game
                    </Link>
                    <Link href="/web/shadow" className="nav-item">
                        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z" /></svg>
                        Shadow Mode
                    </Link>
                    <div className="nav-divider"></div>
                </nav>
                <div className="profile-section">
                    <div className="avatar">{user?.name?.slice(0, 2).toUpperCase() || "B"}</div>
                    <div>
                        <div className="profile-name">{user?.name || "User"}</div>
                        <div className="profile-label">Profile</div>
                    </div>
                </div>
            </aside>

            {/* MAIN */}
            <main className="main">
                {/* Page Header */}
                <motion.div
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="page-header"
                >
                    <div>
                        <div className="card-label">Your Progress</div>
                        <h1>Learning Analytics</h1>
                        <p>A calm look at how far you&apos;ve come.</p>
                    </div>
                    <div className="period-toggle">
                        <button className="period-btn">Week</button>
                        <button className="period-btn active">Month</button>
                        <button className="period-btn">All Time</button>
                    </div>
                </motion.div>

                {/* Overview Stats Row */}
                <div className="overview-row">
                    {[
                        { icon: "📚", num: "148", desc: "Words learned", delta: "↑ 24 this week", color: "indigo" },
                        { icon: "⏱", num: "6.2", unit: "h", desc: "Time practised", delta: "↑ 40 min this week", color: "orange" },
                        { icon: "✅", num: "34", unit: "%", desc: "Journey complete", delta: "↑ 6% this week", color: "green" },
                        { icon: "🎯", num: "19", unit: "%", desc: "Accuracy rate", delta: "Steady", color: "teal", deltaStyle: { color: "#5C6BC0", background: "#E8EAF6" } }
                    ].map((stat, i) => (
                        <motion.div
                            key={i}
                            initial={{ opacity: 0, scale: 0.95 }}
                            animate={{ opacity: 1, scale: 1 }}
                            transition={{ delay: 0.1 * i }}
                            className="card stat-card"
                        >
                            <div className={`stat-icon ${stat.color}`}>{stat.icon}</div>
                            <div className="stat-number">{stat.num}{stat.unit && <span style={{ fontSize: '18px', color: '#9E9E9E' }}>{stat.unit}</span>}</div>
                            <div className="stat-desc">{stat.desc}</div>
                            <div className="stat-delta" style={stat.deltaStyle}>{stat.delta}</div>
                        </motion.div>
                    ))}
                </div>

                {/* Bar Chart + Streak */}
                <div className="graphs-row">
                    {/* Weekly Activity Bar Chart */}
                    <motion.div
                        initial={{ opacity: 0, x: -20 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: 0.4 }}
                        className="card"
                    >
                        <div className="card-label">Activity</div>
                        <div className="card-title">Daily Practice — This Week</div>
                        <div className="bar-chart-wrap chart-area">
                            <div className="gridlines">
                                <div className="gridline"></div>
                                <div className="gridline"></div>
                                <div className="gridline"></div>
                                <div className="gridline"></div>
                            </div>
                            <div className="chart-yaxis">
                                <span>60</span>
                                <span>40</span>
                                <span>20</span>
                                <span>0</span>
                            </div>
                            <div className="chart-body">
                                <div className="bar-chart">
                                    {[
                                        { val: 12, day: "Mon", h: "22%", color: "fill-indigo", op: 0.5 },
                                        { val: 38, day: "Tue", h: "63%", color: "fill-indigo" },
                                        { val: 25, day: "Wed", h: "42%", color: "fill-indigo" },
                                        { val: 52, day: "Thu", h: "87%", color: "fill-indigo" },
                                        { val: 20, day: "Fri", h: "33%", color: "fill-orange" },
                                        { val: 45, day: "Sat", h: "75%", color: "fill-indigo" },
                                        { val: "—", day: "Sun", h: "5%", color: "", bg: "#F3F2EC" }
                                    ].map((col, i) => (
                                        <div key={i} className="bar-col">
                                            <div className="bar-val">{col.val}</div>
                                            <div className="bar-wrap">
                                                <div
                                                    className={`bar ${col.color}`}
                                                    style={{ height: col.h, opacity: col.op, backgroundColor: col.bg }}
                                                ></div>
                                            </div>
                                            <div className="bar-day">{col.day}</div>
                                        </div>
                                    ))}
                                </div>
                            </div>
                        </div>
                        <div style={{ marginTop: '12px', fontSize: '11px', color: '#9E9E9E', fontStyle: 'italic' }}>
                            Minutes practised per day · orange bar = goal met
                        </div>
                    </motion.div>

                    {/* Streak Calendar */}
                    <motion.div
                        initial={{ opacity: 0, x: 20 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: 0.5 }}
                        className="card"
                    >
                        <div className="card-label">Consistency</div>
                        <div className="streak-header">
                            <div>
                                <div className="streak-fire">🔥 14</div>
                                <div className="streak-days">days in a row</div>
                            </div>
                            <div className="streak-badge">Active Streak</div>
                        </div>

                        <div className="cal-labels">
                            {['M', 'T', 'W', 'T', 'F', 'S', 'S'].map((l, i) => (
                                <span key={i} className="cal-label">{l}</span>
                            ))}
                        </div>
                        <div className="calendar-grid">
                            {[...Array(21)].map((_, i) => {
                                let style = "cal-day ";
                                if (i < 13 && i !== 2 && i !== 6) style += "done soft";
                                else if (i >= 13 && i < 20 && i !== 19) style += "done";
                                else if (i === 19) style += "today";
                                else style += "empty";
                                return <div key={i} className={style}></div>;
                            })}
                        </div>
                        <div style={{ marginTop: '14px', fontSize: '11px', color: '#9E9E9E', display: 'flex', gap: '14px', alignItems: 'center' }}>
                            <span style={{ display: 'flex', alignItems: 'center', gap: '5px' }}><span style={{ width: '10px', height: '10px', background: '#2D3A8C', borderRadius: '3px', display: 'inline-block' }}></span>Active</span>
                            <span style={{ display: 'flex', alignItems: 'center', gap: '5px' }}><span style={{ width: '10px', height: '10px', background: '#E8834A', borderRadius: '3px', display: 'inline-block' }}></span>Today</span>
                            <span style={{ display: 'flex', alignItems: 'center', gap: '5px' }}><span style={{ width: '10px', height: '10px', background: '#F3F2EC', borderRadius: '3px', display: 'inline-block' }}></span>Rest day</span>
                        </div>
                    </motion.div>
                </div>

                {/* XP Growth + Skill Bars */}
                <div className="xp-row">
                    {/* XP Line Chart */}
                    <motion.div
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: 0.6 }}
                        className="card"
                    >
                        <div className="card-label">Experience</div>
                        <div className="card-title">XP Growth This Month</div>
                        <div className="xp-meta">
                            <div>
                                <div className="xp-total">2,340 XP</div>
                                <div className="xp-sub">Total experience earned</div>
                            </div>
                            <div style={{ alignSelf: 'flex-end' }}>
                                <div className="xp-delta">↑ 420 XP this week</div>
                            </div>
                        </div>

                        <div className="line-chart-wrap">
                            <svg viewBox="0 0 500 130" preserveAspectRatio="none">
                                <defs>
                                    <linearGradient id="xpGrad" x1="0" y1="0" x2="0" y2="1">
                                        <stop offset="0%" stopColor="#2D3A8C" stopOpacity="0.18" />
                                        <stop offset="100%" stopColor="#2D3A8C" stopOpacity="0" />
                                    </linearGradient>
                                </defs>
                                <line x1="0" y1="30" x2="500" y2="30" stroke="#F3F2EC" strokeWidth="1" />
                                <line x1="0" y1="65" x2="500" y2="65" stroke="#F3F2EC" strokeWidth="1" />
                                <line x1="0" y1="100" x2="500" y2="100" stroke="#F3F2EC" strokeWidth="1" />
                                <path d="M0,115 C40,105 70,90 110,80 C150,70 180,72 220,60 C260,48 290,50 330,35 C370,20 400,22 440,15 C460,12 480,10 500,8 L500,130 L0,130 Z" fill="url(#xpGrad)" />
                                <path d="M0,115 C40,105 70,90 110,80 C150,70 180,72 220,60 C260,48 290,50 330,35 C370,20 400,22 440,15 C460,12 480,10 500,8" fill="none" stroke="#2D3A8C" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" />
                                <circle cx="0" cy="115" r="3.5" fill="#2D3A8C" />
                                <circle cx="110" cy="80" r="3.5" fill="#2D3A8C" />
                                <circle cx="220" cy="60" r="3.5" fill="#2D3A8C" />
                                <circle cx="330" cy="35" r="3.5" fill="#2D3A8C" />
                                <circle cx="500" cy="8" r="4.5" fill="#E8834A" stroke="white" strokeWidth="1.5" />
                            </svg>
                        </div>
                        <div className="xp-month-labels">
                            <span>Feb 1</span><span>Feb 8</span><span>Feb 15</span><span>Feb 21</span>
                        </div>
                    </motion.div>

                    {/* Skill Progress */}
                    <motion.div
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: 0.7 }}
                        className="card"
                    >
                        <div className="card-label">Skills</div>
                        <div className="card-title">Skill Breakdown</div>
                        <div className="skills-list">
                            {[
                                { emoji: "👂", name: "Listening", pct: 72, color: "fill-indigo", hint: "Your strongest skill — keep it up." },
                                { emoji: "📖", name: "Vocabulary", pct: 58, color: "fill-green", hint: "Growing steadily, 148 words so far." },
                                { emoji: "🗣️", name: "Speaking", pct: 41, color: "fill-orange", hint: "Try Shadow Mode to build confidence." },
                                { emoji: "✍️", name: "Reading", pct: 34, color: "fill-teal", hint: "Gurmukhi script — still early days." }
                            ].map((skill, i) => (
                                <div key={i} className="skill-row">
                                    <div className="skill-top">
                                        <div className="skill-name"><span className="skill-emoji">{skill.emoji}</span> {skill.name}</div>
                                        <div className="skill-pct">{skill.pct}%</div>
                                    </div>
                                    <div className="skill-track"><div className={`skill-fill ${skill.color}`} style={{ width: `${skill.pct}%` }}></div></div>
                                    <div className="skill-hint">{skill.hint}</div>
                                </div>
                            ))}
                        </div>
                    </motion.div>
                </div>

                {/* Bottom Row: Recent Sessions + Monthly Mix */}
                <div className="bottom-row">
                    {/* Recent Sessions */}
                    <motion.div
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: 0.8 }}
                        className="card"
                    >
                        <div className="card-label">History</div>
                        <div className="card-title">Recent Sessions</div>
                        {[
                            { color: "#2D3A8C", name: "Flashcards — Daily Greetings", meta: "Today · 18 min · 12 cards reviewed", xp: "+80 XP" },
                            { color: "#E8834A", name: "Scenario — At the Sabzi Mandi", meta: "Yesterday · 25 min · Scene 2 of 4", xp: "+120 XP" },
                            { color: "#5A9E7A", name: "Flashcards — Market Vocabulary", meta: "Feb 19 · 12 min · 8 new words", xp: "+60 XP" },
                            { color: "#4A9E9A", name: "Shadow Mode — Greeting Practice", meta: "Feb 18 · 10 min · 3 phrases", xp: "+45 XP" },
                            { color: "#5C6BC0", name: "Flashcards — Family Words", meta: "Feb 17 · 15 min · 10 cards", xp: "+70 XP" }
                        ].map((session, i) => (
                            <div key={i} className="session-row">
                                <div className="session-dot" style={{ background: session.color }}></div>
                                <div className="session-info">
                                    <div className="session-name">{session.name}</div>
                                    <div className="session-meta">{session.meta}</div>
                                </div>
                                <div className="session-xp">{session.xp}</div>
                            </div>
                        ))}
                    </motion.div>

                    {/* Monthly Mix Donut + Motivation */}
                    <motion.div
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: 0.9 }}
                        className="card"
                        style={{ display: 'flex', flexDirection: 'column', gap: '22px' }}
                    >
                        <div>
                            <div className="card-label">This Month</div>
                            <div className="card-title">Practice Mix</div>
                            <div className="donut-wrap">
                                <svg className="donut-svg" width="110" height="110" viewBox="0 0 110 110">
                                    <circle cx="55" cy="55" r="40" fill="none" stroke="#E8EAF6" strokeWidth="16" />
                                    <circle cx="55" cy="55" r="40" fill="none" stroke="#2D3A8C" strokeWidth="16" strokeDasharray="95.5 155.7" transform="rotate(-90 55 55)" />
                                    <circle cx="55" cy="55" r="40" fill="none" stroke="#5A9E7A" strokeWidth="16" strokeDasharray="75.4 175.8" strokeDashoffset="-95.5" transform="rotate(-90 55 55)" />
                                    <circle cx="55" cy="55" r="40" fill="none" stroke="#E8834A" strokeWidth="16" strokeDasharray="50.2 201" strokeDashoffset="-170.9" transform="rotate(-90 55 55)" />
                                    <circle cx="55" cy="55" r="40" fill="none" stroke="#4A9E9A" strokeWidth="16" strokeDasharray="30.1 221.1" strokeDashoffset="-221.1" transform="rotate(-90 55 55)" />
                                    <text x="55" y="51" textAnchor="middle" fontFamily="DM Serif Display,serif" fontSize="14" fill="#2D3A8C">6.2h</text>
                                    <text x="55" y="64" textAnchor="middle" fontFamily="DM Sans,sans-serif" fontSize="8" fill="#9E9E9E">total</text>
                                </svg>

                                <div className="donut-legend">
                                    {[
                                        { color: "#2D3A8C", name: "Listening", pct: "38%" },
                                        { color: "#5A9E7A", name: "Vocabulary", pct: "30%" },
                                        { color: "#E8834A", name: "Speaking", pct: "20%" },
                                        { color: "#4A9E9A", name: "Reading", pct: "12%" }
                                    ].map((leg, i) => (
                                        <div key={i} className="legend-row">
                                            <div className="legend-dot" style={{ background: leg.color }}></div>
                                            <div className="legend-name">{leg.name}</div>
                                            <div className="legend-pct">{leg.pct}</div>
                                        </div>
                                    ))}
                                </div>
                            </div>
                        </div>

                        <div className="motivation-note">
                            &quot;You&apos;ve learned more Punjabi this month than most people learn in a year of classroom lessons. ਸ਼ਾਬਾਸ਼, {user?.name?.split(' ')[0] || "Aryan"}.&quot;
                        </div>
                    </motion.div>
                </div>
            </main>
        </div>
    );
}
