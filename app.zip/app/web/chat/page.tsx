"use client";

import { useState, useEffect, useRef, useCallback } from "react";
import Link from "next/link";
import { AnimatePresence, motion } from "framer-motion";
import "./Chat.css";

type UserData = {
    name: string;
    age: string;
    area: string;
    id: string;
    createdAt: string;
    updatedAt: string;
};

type Message = {
    id: string;
    role: "user" | "assistant";
    content: string;
    punjabiText?: string;
    transliteration?: string;
    culturalNote?: string;
    note?: string;
};

const HISTORY = [
    { id: "1", title: "Greetings in Punjabi", active: true },
    { id: "2", title: "Market Vocabulary Help" },
    { id: "3", title: "How to say I'm hungry" },
    { id: "4", title: "Practice — Family Words" },
    { id: "5", title: "Translating a phrase" },
    { id: "6", title: "Numbers and counting" },
];

const INITIAL_MESSAGES: Message[] = [
    {
        id: "1",
        role: "user",
        content: "How do I say good morning in Punjabi?",
    },
    {
        id: "2",
        role: "assistant",
        content: "Great question! Good morning in Punjabi is:",
        punjabiText: "ਸਤ ਸ੍ਰੀ ਅਕਾਲ",
        transliteration: "Sat Srī Akāl",
        culturalNote: "This phrase literally means \"God is eternal truth\" — it's a Sikh greeting used any time of day, not just mornings. Using it shows deep cultural respect.",
        note: "ਪੰਜਾਬੀ phrase above · tap a word to see its meaning",
    },
    {
        id: "3",
        role: "user",
        content: "What about good evening?",
    },
    {
        id: "4",
        role: "assistant",
        content: "For good evening, you can say:",
        punjabiText: "ਸ਼ੁਭ ਸ਼ਾਮ",
        transliteration: "Shubh Shām",
        culturalNote: "This is a more modern, Hindi-influenced phrase. Many Punjabi speakers will smile warmly when they hear it — it shows effort and care.",
        note: "ਪੰਜਾਬੀ translation above",
    },
    {
        id: "5",
        role: "user",
        content: "Can you make me practice?",
    },
    {
        id: "6",
        role: "assistant",
        content: "Absolutely, let's practice! 🎯\n\nI'll say a Punjabi phrase and you translate it to English. No pressure — every attempt is progress.\n\nHere's your first one:",
        punjabiText: "ਤੁਸੀਂ ਕਿਵੇਂ ਹੋ?",
        transliteration: "Tusīṃ kivēṃ ho?",
        note: "Take your time — what does this phrase mean?",
    },
];

export default function ChatPage() {
    const [user, setUser] = useState<UserData | null>(null);
    const [messages, setMessages] = useState<Message[]>(INITIAL_MESSAGES);
    const [inputValue, setInputValue] = useState("");
    const [isTyping, setIsTyping] = useState(false);
    const [showWelcome, setShowWelcome] = useState(false);
    const scrollRef = useRef<HTMLDivElement>(null);
    const inputRef = useRef<HTMLTextAreaElement>(null);

    useEffect(() => {
        const fetchUser = async () => {
            try {
                const res = await fetch("/web/api/user-details");
                const data = await res.json();
                setUser(data);
            } catch (error) {
                console.error("Failed to fetch user:", error);
            }
        };
        fetchUser();
    }, []);

    useEffect(() => {
        if (scrollRef.current) {
            scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
        }
    }, [messages, isTyping]);

    const handleSend = useCallback(() => {
        if (!inputValue.trim()) return;
        const userMessage: Message = {
            id: Date.now().toString(),
            role: "user",
            content: inputValue.trim(),
        };
        setMessages(prev => [...prev, userMessage]);
        setInputValue("");
        setShowWelcome(false);
        setIsTyping(true);

        setTimeout(() => {
            setIsTyping(false);
            const botReply: Message = {
                id: (Date.now() + 1).toString(),
                role: "assistant",
                content: "ਬਹੁਤ ਵਧੀਆ! That's a great effort. Keep practising — you're making real progress.",
                note: "Every question brings you closer to fluency.",
            };
            setMessages(prev => [...prev, botReply]);
        }, 1800);
    }, [inputValue]);

    const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
        if (e.key === "Enter" && !e.shiftKey) {
            e.preventDefault();
            handleSend();
        }
    };

    const handleNewChat = () => {
        setMessages([]);
        setShowWelcome(true);
        setInputValue("");
    };

    const initials = user?.name?.slice(0, 2).toUpperCase() || "U";
    const firstName = user?.name?.split(" ")[0] || "Learner";

    return (
        <div className="chat-container">

            {/* ══════════════════════════════════
                COLUMN 1 — Standard Nav Sidebar
                (identical shell to Dashboard/Game)
                ══════════════════════════════════ */}
            <aside className="sidebar">
                <div className="logo">BOLI</div>
                <div className="logo-sub">Language Learning</div>

                <nav className="nav">
                    <Link href="/web/dashboard" className="nav-item">
                        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                            <rect x="3" y="3" width="7" height="7" rx="1" /><rect x="14" y="3" width="7" height="7" rx="1" />
                            <rect x="3" y="14" width="7" height="7" rx="1" /><rect x="14" y="14" width="7" height="7" rx="1" />
                        </svg>
                        Dashboard
                    </Link>

                    <Link href="/web/analyse" className="nav-item">
                        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                            <line x1="18" y1="20" x2="18" y2="10" /><line x1="12" y1="20" x2="12" y2="4" /><line x1="6" y1="20" x2="6" y2="14" />
                        </svg>
                        Analyse
                    </Link>

                    <Link href="/web/chat" className="nav-item active">
                        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                            <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z" />
                        </svg>
                        Chat
                    </Link>

                    <Link href="/web/game" className="nav-item">
                        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                            <line x1="6" y1="12" x2="10" y2="12" /><line x1="8" y1="10" x2="8" y2="14" />
                            <circle cx="15" cy="11" r="1" fill="currentColor" /><circle cx="17" cy="13" r="1" fill="currentColor" />
                            <rect x="2" y="6" width="20" height="12" rx="4" />
                        </svg>
                        Game
                    </Link>

                    <Link href="/web/shadow" className="nav-item">
                        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                            <path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z" />
                        </svg>
                        Shadow Mode
                    </Link>

                    <div className="nav-divider" />
                </nav>

                <div className="profile-section">
                    <div className="avatar">{initials}</div>
                    <div>
                        <div className="profile-name">{user?.name || "Learner"}</div>
                        <div className="profile-label">Punjabi Learner</div>
                    </div>
                </div>
            </aside>

            {/* ══════════════════════════════════
                COLUMN 2 — Main Chat Area
                ══════════════════════════════════ */}
            <div className="chat-main">
                {/* Top Bar */}
                <div className="chat-topbar">
                    <div className="topbar-left">
                        <div className="topbar-title">Greetings in Punjabi</div>
                        <div className="topbar-sub">Practising with BOLI · Punjabi</div>
                    </div>
                    <div className="topbar-right">
                        <div className="lang-badge">
                            <span className="lang-badge-dot"></span>
                            ਪੰਜਾਬੀ · Active
                        </div>
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#9E9E9E" strokeWidth="2" strokeLinecap="round">
                            <circle cx="12" cy="12" r="3" /><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83-2.83l.06-.06A1.65 1.65 0 0 0 4.68 15a1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 2.83-2.83l.06.06A1.65 1.65 0 0 0 9 4.68a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 2.83l-.06.06A1.65 1.65 0 0 0 19.4 9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z" />
                        </svg>
                    </div>
                </div>

                {/* Scroll Area */}
                <div className="chat-scroll" ref={scrollRef}>
                    <div className="chat-inner">

                        {/* Welcome State */}
                        <AnimatePresence>
                            {showWelcome && messages.length === 0 && (
                                <motion.div
                                    key="welcome"
                                    initial={{ opacity: 0, y: 20 }}
                                    animate={{ opacity: 1, y: 0 }}
                                    exit={{ opacity: 0, y: -10 }}
                                    className="welcome-state"
                                >
                                    <div className="welcome-logo">BOLI</div>
                                    <div className="welcome-greeting">ਸਤ ਸ੍ਰੀ ਅਕਾਲ, {firstName}!</div>
                                    <p className="welcome-sub">Your safe space to practise Punjabi. Ask anything, make mistakes freely.</p>
                                    <div className="suggestion-chips">
                                        {["How do I greet an elder?", "Teach me 5 market words", "Correct my sentence"].map(chip => (
                                            <button key={chip} className="chip" onClick={() => { setInputValue(chip); inputRef.current?.focus(); }}>
                                                {chip}
                                            </button>
                                        ))}
                                    </div>
                                </motion.div>
                            )}
                        </AnimatePresence>

                        {/* Messages */}
                        <AnimatePresence>
                            {messages.map((msg) => (
                                <motion.div
                                    key={msg.id}
                                    initial={{ opacity: 0, y: 12 }}
                                    animate={{ opacity: 1, y: 0 }}
                                    transition={{ duration: 0.3 }}
                                    className={`msg-row ${msg.role}`}
                                >
                                    <div className={`bubble ${msg.role}`}>
                                        {msg.content}
                                        {msg.punjabiText && (
                                            <>
                                                <span className="punjabi-script">{msg.punjabiText}</span>
                                                {msg.transliteration && (
                                                    <span className="transliteration">{msg.transliteration}</span>
                                                )}
                                            </>
                                        )}
                                        {msg.culturalNote && (
                                            <div className="cultural-note">🪔 {msg.culturalNote}</div>
                                        )}
                                    </div>
                                    {msg.note && (
                                        <div className="bubble-note">{msg.note}</div>
                                    )}
                                </motion.div>
                            ))}
                        </AnimatePresence>

                        {/* Typing Indicator */}
                        <AnimatePresence>
                            {isTyping && (
                                <motion.div
                                    key="typing"
                                    initial={{ opacity: 0, y: 8 }}
                                    animate={{ opacity: 1, y: 0 }}
                                    exit={{ opacity: 0 }}
                                    className="msg-row assistant"
                                >
                                    <div className="typing-bubble">
                                        <div className="typing-dot" />
                                        <div className="typing-dot" />
                                        <div className="typing-dot" />
                                    </div>
                                </motion.div>
                            )}
                        </AnimatePresence>
                    </div>
                </div>

                {/* Input Zone */}
                <div className="chat-input-zone">
                    <div className="input-row">
                        <textarea
                            ref={inputRef}
                            className="chat-input"
                            rows={1}
                            value={inputValue}
                            onChange={e => setInputValue(e.target.value)}
                            onKeyDown={handleKeyDown}
                            placeholder="Ask anything in Punjabi, or ask BOLI to teach you…"
                        />
                        <button
                            className="send-btn"
                            onClick={handleSend}
                            disabled={!inputValue.trim() || isTyping}
                        >
                            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                                <line x1="22" y1="2" x2="11" y2="13" />
                                <polygon points="22 2 15 22 11 13 2 9 22 2" fill="white" stroke="none" />
                            </svg>
                        </button>
                    </div>
                    <div className="input-reassurance">
                        BOLI is here to help you learn, not judge. Every question is a good question.
                    </div>
                </div>
            </div>

            {/* ══════════════════════════════════
                COLUMN 3 — Chat History Panel (right edge)
                ══════════════════════════════════ */}
            <div className="chat-panel">
                <div className="chat-panel-top">
                    <button className="new-chat-btn" onClick={handleNewChat}>
                        <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round">
                            <line x1="12" y1="5" x2="12" y2="19" /><line x1="5" y1="12" x2="19" y2="12" />
                        </svg>
                        New Chat
                    </button>
                </div>

                <div className="history-label">Recent Conversations</div>

                <div className="chat-history">
                    {HISTORY.map(item => (
                        <div key={item.id} className={`history-item ${item.active ? "active" : ""}`}>
                            <svg className="history-icon" width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                                <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z" />
                            </svg>
                            <span className="history-title">{item.title}</span>
                        </div>
                    ))}
                </div>
            </div>

        </div>
    );
}
