"use client";

import { useState, useEffect } from "react";
import Link from "next/link";
import { motion } from "framer-motion";
import "./Dashboard.css";

type UserData = {
    name: string;
    age: string;
    area: string;
    id: string;
    createdAt: string;
    updatedAt: string;
};

export default function DashboardPage() {
    const [user, setUser] = useState<UserData | null>(null);
    const [isLoading, setIsLoading] = useState(true);

    useEffect(() => {
        const fetchUser = async () => {
            try {
                const res = await fetch("/web/api/user-details");
                const data = await res.json();
                setUser(data);
            } catch (error) {
                console.error("Failed to fetch user:", error);
            } finally {
                setIsLoading(false);
            }
        };
        fetchUser();
    }, []);

    const formatDate = (dateString: string) => {
        if (!dateString) return "Recent";
        const date = new Date(dateString);
        return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
    };

    const getCurrentDate = () => {
        return new Date().toLocaleDateString('en-US', {
            weekday: 'long',
            day: 'numeric',
            month: 'short',
            year: 'numeric'
        });
    };

    if (isLoading) {
        return (
            <div className="min-h-screen bg-[#FAF9F3] flex items-center justify-center">
                <div className="w-12 h-12 border-4 border-[#2D3A8C] border-t-transparent rounded-full animate-spin" />
            </div>
        );
    }

    return (
        <div className="dashboard-container">
            {/* ── SIDEBAR ── */}
            <aside className="sidebar">
                <div className="logo">BOLI</div>
                <div className="logo-sub">Language Learning</div>

                <nav className="nav">
                    <Link href="/web/dashboard" className="nav-item active">
                        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                            <rect x="3" y="3" width="7" height="7" rx="1" /><rect x="14" y="3" width="7" height="7" rx="1" />
                            <rect x="3" y="14" width="7" height="7" rx="1" /><rect x="14" y="14" width="7" height="7" rx="1" />
                        </svg>
                        Dashboard
                    </Link>

                    <Link href="/web/analyse" className="nav-item">
                        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                            <line x1="18" y1="20" x2="18" y2="10" /><line x1="12" y1="20" x2="12" y2="4" />
                            <line x1="6" y1="20" x2="6" y2="14" />
                        </svg>
                        Analyse
                    </Link>

                    <Link href="/web/chat" className="nav-item">
                        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                            <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z" />
                        </svg>
                        Chat
                    </Link>

                    <Link href="/web/game" className="nav-item">
                        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                            <line x1="6" y1="12" x2="10" y2="12" /><line x1="8" y1="10" x2="8" y2="14" />
                            <circle cx="15" cy="11" r="1" fill="currentColor" /><circle cx="17" cy="13" r="1" fill="currentColor" />
                            <rect x="2" y="6" width="20" height="12" rx="4" />
                        </svg>
                        Game
                    </Link>

                    <Link href="/web/shadow" className="nav-item">
                        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                            <path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z" />
                        </svg>
                        Shadow Mode
                    </Link>

                    <div className="nav-divider"></div>
                </nav>

                <div className="profile-section">
                    <div className="avatar">{user?.name?.slice(0, 2).toUpperCase() || "B"}</div>
                    <div>
                        <div className="profile-name">{user?.name || "User"}</div>
                        <div className="profile-label">Profile</div>
                    </div>
                </div>
            </aside>

            {/* ── MAIN CONTENT ── */}
            <main className="main">
                <motion.div
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="greeting-row"
                >
                    <div className="greeting-text">
                        <h1>ਸਤ ਸ੍ਰੀ ਅਕਾਲ, {user?.name?.split(' ')[0] || "Learner"} 👋</h1>
                        <p>You&apos;re doing great — keep the momentum going.</p>
                    </div>
                    <div className="date-pill">
                        <span className="date-dot"></span>
                        {getCurrentDate()}
                    </div>
                </motion.div>

                <div className="top-row">
                    {/* EXP Card */}
                    <motion.div
                        initial={{ opacity: 0, scale: 0.95 }}
                        animate={{ opacity: 1, scale: 1 }}
                        transition={{ delay: 0.1 }}
                        className="card exp-card"
                    >
                        <div className="exp-ring-wrap">
                            <svg viewBox="0 0 120 120">
                                <circle className="exp-ring-bg" cx="60" cy="60" r="54" />
                                <circle className="exp-ring-fill" cx="60" cy="60" r="54" />
                            </svg>
                            <div className="exp-center">
                                <div className="exp-number">2,340</div>
                                <div className="exp-label">EXP</div>
                            </div>
                        </div>

                        <div className="level-badge">
                            <div className="level-badge-dot"></div>
                            <span>Level 7 — Learner</span>
                        </div>

                        <div className="exp-hint">660 XP to reach Level 8</div>
                    </motion.div>

                    {/* Personal Info Card */}
                    <motion.div
                        initial={{ opacity: 0, scale: 0.95 }}
                        animate={{ opacity: 1, scale: 1 }}
                        transition={{ delay: 0.2 }}
                        className="card info-card"
                    >
                        <div className="card-title">Personal Summary</div>

                        <div className="info-row">
                            <span className="info-key">Name</span>
                            <span className="info-val">{user?.name || "Not set"}</span>
                        </div>
                        <div className="info-row">
                            <span className="info-key">Learning Since</span>
                            <span className="info-val">{formatDate(user?.createdAt || "")}</span>
                        </div>
                        <div className="info-row">
                            <span className="info-key">Location</span>
                            <span className="info-pill">{user?.area || "Not set"}</span>
                        </div>
                        <div className="info-row">
                            <span className="info-key">Daily Goal</span>
                            <span className="info-val">20 min</span>
                        </div>
                        <div className="info-row">
                            <span className="info-key">Streak</span>
                            <span className="info-pill orange">🔥 14 days</span>
                        </div>
                        <div className="info-row">
                            <span className="info-key">Words Learned</span>
                            <span className="info-val">148 words</span>
                        </div>
                    </motion.div>
                </div>

                {/* Language Card — wide bottom */}
                <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.3 }}
                    className="card lang-card"
                >
                    <div className="lang-icon-wrap">🎯</div>

                    <div className="lang-info">
                        <div className="lang-title">Punjabi — ਪੰਜਾਬੀ</div>
                        <div className="lang-sub">Gurmukhi script · Adult Stage · Scene 3 of 7</div>

                        <div className="progress-row">
                            <div className="progress-track">
                                <div className="progress-fill" style={{ width: '34%' }}></div>
                            </div>
                            <div className="progress-pct">34%</div>
                        </div>

                        <div className="hints-row">
                            <div className="hint-chip"><span className="dot dot-green"></span>Greetings done</div>
                            <div className="hint-chip"><span className="dot dot-orange"></span>Daily life active</div>
                            <div className="hint-chip"><span className="dot dot-indigo"></span>Market scene next</div>
                        </div>
                    </div>
                </motion.div>

                <div className="mt-4 flex justify-center">
                    <Link
                        href="/web/try-flashcards"
                        className="text-[#2D3A8C] font-semibold text-sm hover:underline"
                    >
                        Go to Practice Session →
                    </Link>
                </div>
            </main>
        </div>
    );
}
